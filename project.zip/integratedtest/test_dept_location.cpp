#include <iostream>
#include "../businessobject/DeptLocation.h"
#include "../businessobject/Project.h"
using namespace std;

int main(){
    cout << "hello" << endl;
    return 0;
}