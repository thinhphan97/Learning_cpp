#ifndef Project_businessobject_BaseObject_h_
#define Project_businessobject_BaseObject_h_

class BaseObject
{
public:
};

#endif