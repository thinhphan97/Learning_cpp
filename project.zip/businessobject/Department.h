#ifndef Project_businessobject_Department_h_
#define Project_businessobject_Department_h_
#include<string>
#include"BaseObject.h"
#include "../libs/json.hpp"
using json = nlohmann::json;

using namespace std;
class Department:public BaseObject{
    private:
        int Id;
        string DName;
        int DNumber;
        long MgrSSN;
        string MgrStartDate;
    public:
        Department();
        Department(string Dname, int DNumber, long MgrSSN, string MgrStartDate);
        void SetId(int Id);
        int GetId();
        void SetSubId();
        long GetMgrSSN();
        json ToJson();
        
};

#endif