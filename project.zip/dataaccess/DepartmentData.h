#ifndef Project_dataaccess_DepartmentData_h_
#define Project_dataaccess_DepartmentData_h_
#include <vector>
#include "../businessobject/Department.h"
#include "../businessobject/BaseObject.h"

using namespace std;

class DepartmentData
{
private:
    vector<Department> _data;
    int _MaxId;
    string file_name;
public:
    DepartmentData();
    DepartmentData(string file_name);
    int AddData(BaseObject* baseobject);
    void DeleteData(int DNumber);
    int UpdateData(BaseObject* baseobject);
    vector<BaseObject*> SelectAllData();
    Employee SelectData(long mgrssn);
    int PullFile();
    int GetMaxId();
};
#endif