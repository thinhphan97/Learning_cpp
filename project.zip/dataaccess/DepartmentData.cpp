#include "DepartmentData.h"

DepartmentData::DepartmentData(){
    _data.resize(0);
    _MaxId = 0;
}
DepartmentData::DepartmentData(string file_name){
    _MaxId = 0;
    _data.resize(0);
    this->file_name = file_name;
    ifstream inFile(file_name);
    const int maxSize = 255;
    char buff[maxSize];
    while (inFile.getline(buff,maxSize)){
        json j = json::parse(buff);

        Employee p(
            j["Id"],
            j["DName"],
            j["DNumber"],
            j["MgrSSN"],
            j["MgrStartDate"]
            );
        p.SetId(j["Id"]);
        _data.push_back(p);
        _MaxId= j["Id"];
    }
    inFile.close();
}