#include "businessobject/Employee.h"
#include "dataaccess/DataAccess.h"
#include "dataaccess/EmployeeData.h"
#include "businessobject/BaseObject.h"
#include "iostream"
#include <vector>

using namespace std;

int main(){
    BaseObject* e = new Employee("thinh","B","phan",123456456,"1997-09-13", "vietnam",'M', 30000, 333445555, 5);
    DataAccess* data = new EmployeeData("Employee.data");
    cout << data->AddData(e)<< endl;
    // long ssn;
    // cout << "enter ssn delete: "; cin>> ssn;
    // BaseObject* e1 = new Employee(9,"thinh","c","phan",123456457,"1997-09-13", "vietnam",'M', 30000, 333445556, 4);
    // data->UpdateData(e1);
    // vector<BaseObject*> _printdata;
    // _printdata =  data->SelectAllData();
    // for(BaseObject* _data:_printdata){
    //     Employee* _DataAdd = (Employee*) _data;
    //     cout<< _DataAdd->ConvertToString()<<endl;
    // }
    // EmployeeData data1("Employee.data");
    // Employee out = data1.SelectData(666884445);
    // cout << out.ConvertToString()<<endl;
    cout<< data->PullFile();
}